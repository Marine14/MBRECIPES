//
//  MainPageViewController.swift
//  FoodRecipes
//
//

import UIKit

class MainPageViewController: UIViewController {

    @IBOutlet weak var chickenImg: UIImageView!
    @IBOutlet weak var dessertImg: UIImageView!
    @IBOutlet weak var pastaImg: UIImageView!
    @IBOutlet weak var beefImg: UIImageView!
    
    //@IBOutlet weak var beefImg: UIImageView!
    @IBOutlet weak var porkImg: UIImageView!
    @IBOutlet weak var seafoodImg: UIImageView!
    
    @IBOutlet weak var categorieImage: UIImageView!
    @IBOutlet weak var categorieName: UILabel!
//    @IBOutlet weak var etImg: UIImageView!
    
    var categories: [Categorie]?
    var categorieDetails: Categorie?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Api().getCategories() { categoriesResult in
            self.categories = categoriesResult?.categories
            
            DispatchQueue.main.async {
                self.categorieName.text = self.categories!.first!.strCategory!
                let url = URL(string: self.categories!.first!.strCategoryThumb!)!
                self.categorieImage.downloaded(from: url)
                
            }
        }
        
        
        chickenImg.isUserInteractionEnabled = true
        dessertImg.isUserInteractionEnabled = true
        pastaImg.isUserInteractionEnabled = true
        beefImg.isUserInteractionEnabled = true
        porkImg.isUserInteractionEnabled = true
        seafoodImg.isUserInteractionEnabled = true
        
        chickenImg.layer.cornerRadius = 8
        dessertImg.layer.cornerRadius = 8
        pastaImg.layer.cornerRadius = 8
        beefImg.layer.cornerRadius = 8
        porkImg.layer.cornerRadius = 8
        seafoodImg.layer.cornerRadius = 8
        
        let chickenRecognizer = UITapGestureRecognizer(target: self, action: #selector(openChicken))
        let dessertRecognizer = UITapGestureRecognizer(target: self, action: #selector(openDessert))
        let pastaRecognizer = UITapGestureRecognizer(target:self, action: #selector(openPasta))
        
        let beefRecognizer = UITapGestureRecognizer(target: self, action: #selector(openBeef))
        
        let porkRecognizer = UITapGestureRecognizer(target: self, action: #selector(openPork))
        let seafoodRecognizer = UITapGestureRecognizer(target: self, action: #selector(openSeafood))
        
        
        chickenImg.addGestureRecognizer(chickenRecognizer)
        dessertImg.addGestureRecognizer(dessertRecognizer)
        pastaImg.addGestureRecognizer(pastaRecognizer)
        
        beefImg.addGestureRecognizer(beefRecognizer)
        
        porkImg.addGestureRecognizer(porkRecognizer)
        seafoodImg.addGestureRecognizer(seafoodRecognizer)
       
    }

    func pushList(category: Category) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let recipesTableViewController = storyboard.instantiateViewController(withIdentifier: "RecipesTableViewController") as! RecipesTableViewController
        recipesTableViewController.category = category
        self.navigationController?.pushViewController(recipesTableViewController, animated: true)
    }
    
    @objc func openChicken() {
        pushList(category: .chicken)
    }

    
    @objc func openDessert(){
        pushList(category: .dessert)
    }
    
    @objc func openPasta(){
        pushList(category: .pasta)
    }
    
    
    @objc func openBeef(){
        pushList(category: .beef)
    }
    
    
    @objc func openPork(){
        pushList(category: .pork)
    }
    
    @objc func openSeafood(){
        pushList(category: .seafood)
    }
    
    


}
