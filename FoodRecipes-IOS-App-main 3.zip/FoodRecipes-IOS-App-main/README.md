# Food Recipes Application

This is my first IOS App. 

The first page is sign in and sign up page. I controll informations with regex in sign up page. If you do not enter informations, an error pop up will appear.

![Simulator Screen Shot - iPhone 11 - 2021-12-15 at 22 21 14](https://user-images.githubusercontent.com/44964158/146251520-2cadbba9-6885-40dc-9324-21103111a780.png)
![Simulator Screen Shot - iPhone 11 - 2021-12-15 at 22 21 21](https://user-images.githubusercontent.com/44964158/146251541-b3cffc9c-66e4-4bbf-b645-35a2d729a1f0.png)
![Simulator Screen Shot - iPhone 11 - 2021-12-15 at 22 21 27](https://user-images.githubusercontent.com/44964158/146251545-28de1410-23f7-4f41-bd96-346b7953d56c.png)

After sign in or sign up, we see the main page. In this page there are food recipe categories and photos are clickable.

![Simulator Screen Shot - iPhone 11 - 2021-12-15 at 22 24 50](https://user-images.githubusercontent.com/44964158/146251814-41b07411-28a2-48f8-808e-686a736c247d.png)

For example if you click "Dünya Mutfağı" photo you will see registered food recipe names. If you click one, there will be food image and its recipe.

![Simulator Screen Shot - iPhone 11 - 2021-12-15 at 22 27 38](https://user-images.githubusercontent.com/44964158/146252092-46997aa7-b43b-4dbe-8ec2-e8a3fd965423.png)
