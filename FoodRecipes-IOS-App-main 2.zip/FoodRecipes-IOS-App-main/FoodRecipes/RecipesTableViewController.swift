//
//  RecipesTableViewController.swift
//  FoodRecipes
//
//

import UIKit

enum Category {
    case worldKitchen
    case viande
    case huileolive
    case patisserie
    case meze
    case tarte
    case cuisineturque
}

class RecipesTableViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource{
    

    var worldKitchenFoodNames = ["Taco", "Sushi", "Nachos", "Noodle", "Bun"]
    var worldKitchenFoodImages = ["dunyamutfagi", "sushi", "nachos", "noodle", "bun"]
        
    var category: Category!
    
    var foodNames: [String]!
    var foodImages: [String]!
    var chosenFoodName = ""
    var chosenFoodImage = UIImage()
    
    @IBOutlet weak var worldTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        worldTable.delegate = self
        worldTable.dataSource = self
        
        switch category {
        case .worldKitchen:
            navigationItem.title = "Cuisine du monde"
            foodNames = worldKitchenFoodNames
            foodImages = worldKitchenFoodImages
            
        case .viande:
            navigationItem.title = "Viande"
            
        case .some(.huileolive):
            navigationItem.title = "Huile d'olive"
            foodNames = worldKitchenFoodNames
            foodImages = worldKitchenFoodImages
        case .some(.patisserie):
            navigationItem.title = "Patisserie"
            foodNames = worldKitchenFoodNames
            foodImages = worldKitchenFoodImages
        case .some(.meze):
            navigationItem.title = "Meze"
            foodNames = worldKitchenFoodNames
            foodImages = worldKitchenFoodImages
        case .some(.tarte):
            navigationItem.title = "Tarte"
            foodNames = worldKitchenFoodNames
            foodImages = worldKitchenFoodImages
        case .some(.cuisineturque):
            navigationItem.title = "Cuisine turque"
            foodNames = worldKitchenFoodNames
            foodImages = worldKitchenFoodImages
            
        case .none:
            break
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodNames.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = foodNames[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            foodNames.remove(at: indexPath.row)
            foodImages.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.fade)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        chosenFoodName = foodNames[indexPath.row]
        chosenFoodImage = UIImage(named: foodImages[indexPath.row])!
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let recipeViewController = storyboard.instantiateViewController(withIdentifier: "RecipeViewController") as! RecipeViewController
//        recipesTableViewController.category = category
        recipeViewController.selectedFoodName = chosenFoodName
        recipeViewController.selectedImage = chosenFoodImage
        self.navigationController?.pushViewController(recipeViewController, animated: true)
    }

}
